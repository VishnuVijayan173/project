import React from 'react';
import {BrowserRouter, Route, Routes, Router ,Outlet} from 'react-router-dom';
import Header from '../../../components/header/header';
import { Col, Container, Row } from 'react-bootstrap';
import AdminSideBar from '../../../components/app/Admin/SideBAr/SideBar';



function AdminDashboard() {
    return (
        <div>
            <Header/>
            <Container fluid className="Main-content">
                <Row className="full-width row-lg-2">
                <Col  className="col-xs-0 col-md-2 SideBar"><AdminSideBar/></Col>
                <Col  className=" col-xs-12 col-md-10 RightContent"><Outlet /></Col>
                </Row>
            </Container>
        </div>
    );
}
export default AdminDashboard;