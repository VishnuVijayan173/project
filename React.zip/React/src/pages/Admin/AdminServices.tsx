import axios from '../../utils/interceptors';



export function getUsers(){
    return axios.get('https://localhost:44368/User')
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function getRoles(){
    return axios.get('https://localhost:44368/Role')
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function addUser(user:any){
    return axios.post('https://localhost:44368/User/Register' , {
        userName:user[0].value,
        emailAddress:user[1].value,
        password:user[2].value,
        roleID:user[3].value
        })
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function getStatus(){
    return axios.get('https://localhost:44368/Status')
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function getProjects(){
    return axios.get('https://localhost:44368/Project')
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function getAllocations(){
    return axios.get('https://localhost:44368/ProjectAllocation')
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}