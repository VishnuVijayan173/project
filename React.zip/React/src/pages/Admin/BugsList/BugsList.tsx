import React, { useEffect, useState } from 'react';
import { Button, Table } from 'react-bootstrap';
import { getBugs } from '../../User/UserServices/UserServices';
import { getAllocations, getProjects, getStatus } from '../AdminServices';


const AdminBugList = () => {
  const [bugs, setBugs] = useState([]);
  const [isUpdated, setIsupdated] = useState(false);
  const [searchText,setSearchText]= useState('');
  const [bugStatuses, setBugStatuses]= useState<any>([]);
  const [bugProjects, setProjects]= useState<any>([]);
  const [allocations, setAllocations]= useState<any>([]);


  let mounted = true;
    useEffect(() => {
        if (bugs.length && !isUpdated) {
            return;
        }

        GetBugs();

        return () => {
            mounted = false;
            setIsupdated(false);
        };
    }, [isUpdated, bugs]);

    function GetBugs() {
      getBugs().then((data:any) => {
          if (mounted) {
              setBugs(data);
          }

          // eslint-disable-next-line no-console
          console.log(data);
      });
  }
  const Search = (e: any) => {
    e.preventDefault();
    // eslint-disable-next-line no-console
    console.log('abcd');
    const filteredBugs = bugs.filter((bug: any) =>
      bug.bugName.toLowerCase().includes(searchText.toLowerCase())
    );
    setBugs(filteredBugs);
    // eslint-disable-next-line no-console
    console.log(bugs);
  };
  useEffect(() => {
    getStatus().then((data:any) => {
      setBugStatuses(data);
    });
  }, []);
  useEffect(() => {
    getAllocations().then((data:any) => {
      setAllocations(data);
    });
  }, []);
  useEffect(() => {
    getProjects().then((data:any) => {
      setProjects(data);
    });
  }, []);
    return (
        <>
      <div className="container-fluid side-container">
      <div className="row ">
      <input
        type="text"
        placeholder="Search..."
        onChange={(event) => setSearchText(event.target.value)}
      />
       <Button variant="primary" onClick={Search}> Search</Button>{' '}

    </div>
      <div className="row " >
       <p id="before-table"></p>
           <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
           <thead>
               <tr>
               <th>BugID</th>
               <th>Bug Name</th>
               <th>Bug Description</th>
               <th>Bug Status</th>
               <th>Project</th>
               <th>Raised By</th>
               </tr>
           </thead>
           <tbody>
           {bugs?.map((bug:any) => {
            const allocation = allocations.find((allocation: any) =>
            allocation.AllocationID === bug.AllocationID);
           const project = bugProjects.find((project: any) => project.ProjectID === allocation?.ProjectID);
            return <tr key={bug.bugID}>
            <td>{bug.bugID}</td>
            <td>{bug.bugName}</td>
            <td>{bug.bugDescription}</td>
            <td>{bugStatuses.find((status:any) => status.statusID === bug.statusID)?.bugStatus}</td>
                <td>{project.projectName}</td>
            <td>{bug.raisedBy}</td>
        </tr>;
           }
             )};
           </tbody>
       </Table>
       </div>
     </div>
        </>
    );
};
export default AdminBugList;
