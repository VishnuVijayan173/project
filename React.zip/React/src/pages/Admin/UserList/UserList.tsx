import React, { useEffect, useState } from 'react';
import { Button, ButtonToolbar, Card, Form, FormGroup, Modal, Table, ToastContainer } from 'react-bootstrap';
import { getUsers, getRoles, addUser } from '../AdminServices';
import axios from 'axios';
import { toast } from 'react-toastify';

const UserList = (props:any) => {
  const [users, setUsers] = useState([]);
  const [isUpdated, setIsupdated] = useState(false);

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [userName, setUserName] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [password, setPassword] = useState('');
  const [roleId, setRoleId] = useState('');
  const [updatedBy, setUpdatedBy] = useState('');
  const [roles, setRoles] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [newError, setError] = useState<{
    userName?: string;
    password?: string;
    emailAddress?: string;
    roleId?: string;
}>({});
const validate = () => {
    const newError: {
        userName?: string;
        password?: string;
        emailAddress?: string;
        roleId?: string;
    } = {};
    // Check if the username is valid (not empty and less than 50 characters)
    if (!userName) {
        newError.userName = 'Username is required';
    } else if (!userName.match('^(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]+$')) {
        newError.userName = 'Username is not valid';
    }

      // Check if the email is valid (not empty and in the correct format)
      if (!emailAddress || !/^\S+@\S+\.\S+$/.test(emailAddress)) {
        newError.emailAddress = 'Please enter a valid email address';

      }

      // Check if the password is valid (not empty and at least 8 characters long)
      if (!password || password.length < 8) {
        newError.password='Please enter a valid password (at least 8 characters long';
      }

      // Check if a role has been selected
      if (!roleId) {
        newError.roleId='Please enter a role';
      }
      setError(newError);
    return Object.keys(newError).length === 0;
    };

  let mounted = true;
    useEffect(() => {
        if (users.length && !isUpdated) {
            return;
        }

        GetUsers();

        return () => {
            mounted = false;
            setIsupdated(false);
        };
    }, [isUpdated, users]);

    function GetUsers() {
      getUsers().then((data:any) => {
          if (mounted) {
              setUsers(data);
          }

          // eslint-disable-next-line no-console
          console.log(data);
      });
    }
      useEffect(() => {
        getRoles().then((data:any) => {
          setRoles(data);
        });
      }, []);

      const handleSubmit = (e: any) => {
        e.preventDefault();
        if(validate()){
        addUser(e.target).then(
          (result: any) => {
            toast.success('Successfully added', {
              position: 'top-center',
              autoClose: 5001,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: 1,
              theme: 'dark',
            });
            setTimeout(() => {
              window.location.href = 'http://localhost:3000/user';
            }, 800);
            props.setUpdated(true);
          },
          () => {
            toast.error('Failed to add user', {
              position: 'top-center',
              autoClose: 5001,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              progress: 1,
              theme: 'dark',
            });
          }
        );
        }
      };


  return (
    <>
      <div className="container-fluid side-container">
        <ToastContainer/>
        <div className="row ">
          <span>
            <input
              type="text"
              placeholder="Search..."
              onChange={e => (e.target.value)}
            />
            <button>Search</button>
          </span>
        </div>
        <div className="row " >
          <p id="before-table"></p>
          <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
            <thead>
              <tr>
                <th>UserID</th>
                <th>UserName</th>
                <th>Email</th>
              </tr>
            </thead>
            <tbody>
              {users.map((user:any) =>
                <tr key={user.userID}>
                  <td>{user.userID}</td>
                  <td>{user.userName}</td>
                  <td>{user.emailAddress}</td>
                </tr>
              )}
            </tbody>
          </Table>
          <ButtonToolbar>
  <Button variant="primary" onClick={handleShow}>
    Add User
  </Button>
</ButtonToolbar>
<Modal show={show} onHide={handleClose}>
  <Modal.Header closeButton>
    <Modal.Title>Add User Details</Modal.Title>
  </Modal.Header>
  <Modal.Body>
    <Card>
      <Card.Body>
        <Form onSubmit={handleSubmit}>
          <Form.Group>
            <Form.Label htmlFor="userName">Username:</Form.Label>
            <Form.Control type="text" id="userName" value={userName}
             onChange={(event) => setUserName(event.target.value)} />
            {newError.userName && <div className="error">{newError.userName}</div>}
          </Form.Group>
          <Form.Group>
            <Form.Label htmlFor="emailAddress">Email Address:</Form.Label>
            <Form.Control type="email" id="emailAddress" value={emailAddress}
             onChange={(event) => setEmailAddress(event.target.value)} />
            {newError.emailAddress && <div className="error">{newError.emailAddress}</div>}
          </Form.Group>
          <Form.Group>
            <Form.Label htmlFor="password">Password:</Form.Label>
            <Form.Control type="password" id="password" value={password}
             onChange={(event) => setPassword(event.target.value)} />
             {newError.password && <div className="error">{newError.password}</div>}
          </Form.Group>
          <Form.Group>
            <Form.Label htmlFor="roleId">Role:</Form.Label>
            <Form.Control as="select" id="roleId" value={roleId} onChange={(event) => setRoleId(event.target.value)}>
              <option value="">Select a role</option>
              {roles.map((role:any) => (
                <option key={role.roleID} value={role.roleID}>
                  {role.roleName}
                </option>
              ))}
            </Form.Control>
            {newError.roleId && <div className="error">{newError.roleId}</div>}
          </Form.Group>
          <input type="hidden" id="updatedBy" value={updatedBy} />
          {message && <div>{message}</div>}
          <FormGroup>
            <Button variant="primary" type='submit' onClick={handleClose} >
      Save Changes
    </Button></FormGroup>
        </Form>
      </Card.Body>
    </Card>
  </Modal.Body>
  <Modal.Footer>
    <Button variant="secondary" onClick={handleClose}>
      Close
    </Button>

  </Modal.Footer>
</Modal>

       </div>
     </div>
        </>
    );
};
export default UserList;
