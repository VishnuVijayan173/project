import axios from '../../../utils/interceptors';



export function getBugs(){
    return axios.get('https://localhost:44368/Bug')
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function addBug(bug:any){
    // eslint-disable-next-line no-console
    console.log(bug);
    return axios.post('https://localhost:44368/Bug' , bug)
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch(err => console.log('Error: ', err));
}
export function getBugName(SearchText:any){
    return axios.get(`https://localhost:44368/Bug/${SearchText}`,SearchText)
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function deleteBug(bugID:any){
    return axios.delete(`https://localhost:44368/Bug/${bugID}`)
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}
export function updateBug(id:any){
    return axios.put(`https://localhost:44368/Bug/${id}`)
    .then((response:any) => response.data)
    // eslint-disable-next-line no-console
    .catch((err:any) => console.log('Error: ', err));
}