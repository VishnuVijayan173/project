import React, { useEffect, useState } from 'react';
import { Table, ButtonToolbar, FormGroup } from 'react-bootstrap';
//import AddBugModal from './AddBugModal';
import axios from 'axios';
//import { GetBugs } from '../services/BugServices';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { toast, ToastContainer } from 'react-toastify';
import Form from 'react-bootstrap/Form';
import { addBug, deleteBug, getBugs, updateBug } from '../UserServices/UserServices';
import './ManageBugs.css';
import { getAllocations, getProjects, getStatus } from '../../Admin/AdminServices';



const ManageBugs = (props: any) => {

  const handleClose = () => setShow(false);
  const handleClose1 = () => setShow1(false);
  const handleShow = () => setShow(true);
  const handleShow1 = () => setShow1(true);

  const [show, setShow] = useState(false);
  const [show1, setShow1] = useState(false);
  const [bugs, setBugs] = useState([]);
  const [isUpdated, setIsUpdated] = useState(false);


  const [editBugName, setEditBugName] = useState('');
  const [editBugDescription, setEditBugDescription] = useState('');
  const [editBugStatus, setEditBugStatus] = useState('');
  const [editProject, setEditProject] = useState('');
  const [editRaisedBy, setEditRaisedBy] = useState('');
  const [id, setBugID] = useState('');
  const [bugStatuses, setBugStatuses]= useState<any>([0]);
  const [bugProjects, setProjects]= useState<any>([0]);
  const [allocations, setAllocations]= useState<any>([0]);
  useEffect(() => {
    getStatus().then((data:any) => {
      setBugStatuses(data);
    });
  }, [0]);

  useEffect(() => {
    getAllocations().then((data:any) => {
      setAllocations(data);
    });
  }, [0]);
  useEffect(() => {
    getProjects().then((data:any) => {
      setProjects(data);
    });
  }, [0]);


  let mounted = true;
  useEffect(() => {

    if (bugs?.length && !isUpdated) {
        return;
    }
    GetBugs();
    return () => {
        mounted = false;
        setIsUpdated(false);
    };
}, [isUpdated, bugs]);

function GetBugs() {
    getBugs().then((data:any) => {
        if (mounted) {
            setBugs(data);
        }
    });
}



const handleSubmit = (e: any) => {
    e.preventDefault();
    addBug({bugName: editBugName,
    bugDescription: editBugDescription,
statusID:editBugStatus,
allocationID: editProject,
raisedBy: editRaisedBy
}).then(
        (result:any) => {
            toast.success(result.message, {
                position: 'top-center',
                autoClose: 5001,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 1,
                theme: 'dark',
            });
            window.location.href = 'http://localhost:3003/dashboard/manage';
            // Set the updated flag in parent component
            props.setUpdated(true);
        },
        // If failed, show error message
        () => {
            toast.error('Failed to add bug', {
                position: 'top-center',
                autoClose: 5001,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: 1,
                theme: 'dark',
            });
        }
    );
};
 const handleDelete = async (e: any, bugID: string) => { e.preventDefault();
   try { const response = await deleteBug(bugID);
     // eslint-disable-next-line no-console
     console.log('response', response);
      window.location.href = 'http://localhost:3000/admin/manage';
      // alert(response);
     } catch (error) {
       // eslint-disable-next-line no-console
       console.error(error); } };

const handleSubmit1 = async (e: any, id: string)=>{ e.preventDefault();
  try { const response = await updateBug(id);
    // eslint-disable-next-line no-console
    console.log('response', response);
  }
   catch (error) {
  // eslint-disable-next-line no-console
  console.error(error); } };



  return (
    <div className="container-fluid side-container">
      <ToastContainer />
      <div className="row side-row">
        <p id="manage"></p>
        <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
          <thead>
            <tr>
              <th >BugID</th>
              <th>Bug Name</th>
              <th>Bug Description</th>
              <th>Bug Status</th>
              <th>Project</th>
              <th>Raised By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
          {bugs?.map((bug:any) =>
              {
                const allocation = allocations.find((allocation: any) =>
                 allocation.AllocationID === bug.AllocationID);
                const project = bugProjects.find((project: any) => project.ProjectID === allocation?.ProjectID);
                setBugID(bug.bugID);
              return <tr key={bug.bugID}>
                <td>{bug.bugID}</td>
                <td>{bug.bugName}</td>
                <td>{bug.bugDescription}</td>
                <td>{bugStatuses.find((status:any) => status.statusID === bug.statusID)?.bugStatus}</td>
                <td>{project.projectName}</td>
                <td>{bug.raisedBy}</td>
                <td>
                  <Button className="mr-2" variant="danger"
                  onClick={(event) => handleDelete(event, bug.bugID)}
                  >
                    <RiDeleteBin5Line />
                  </Button>
                  <span>&nbsp;&nbsp;&nbsp;</span>
                  <Button className="mr-2"
                    onClick={handleShow1}
                  >
                    <FaEdit className="mr-2" size={20} onClick={() => {
                      setEditBugName(bug.BugName);
                      setEditBugDescription(bug.BugDescription);
                      setEditBugStatus(bug.StatusID);
                      setEditProject(project?.ProjectID);
                      setEditRaisedBy(bug.RaisedBy);
                      handleShow1();
                    }} />
                  </Button>

                </td>
              </tr>;
            }
            )}
          </tbody>

        </Table>
        <ButtonToolbar>
          <Button variant="primary"
          //  onClick={handleShow}
            >
            Add Bug
          </Button>
        </ButtonToolbar>
        <Modal show={show}
        //  onHide={()=>handleClose}
         >
        <Modal.Header closeButton>
          <Modal.Title>Add Bug Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <Form>
            <div className="container">
              <div>
                <label>Bug Name</label>
                <input type="text" className="form-control" placeholder="Enter BugName"
                  value={editBugName} onChange={(e) => setEditBugName(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Description</label>
                <input type="text" className="form-control" placeholder="Enter description"
                  value={editBugDescription} onChange={(e) => setEditBugDescription(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Status</label>
                <input type="text" className="form-control" placeholder="Enter Status"
                  value={editBugStatus} onChange={(e) => setEditBugStatus(e.target.value)}
                />
              </div>
              <div>
                <label>Project</label>
                <input type="text" className="form-control" placeholder="Enter Project"
                  value={editProject} onChange={(e) => setEditProject(e.target.value)}
                />
              </div>
              <div>
                <label>Raised By</label>
                <input type="text" className="form-control" placeholder="Raised By"
                  value={editRaisedBy} onChange={(e) => setEditRaisedBy(e.target.value)}
                />
              </div>
            </div>
            <div>
                <FormGroup>
                <Button variant="secondary"
                // onClick={()=>handleClose}
                >
            Close
          </Button>
                </FormGroup>
                <FormGroup><Button variant="primary" type='submit' onClick={handleSubmit}>
            Save Changes
          </Button></FormGroup>
            </div>
            </Form>
          </Modal.Body>
        <Modal.Footer>
        </Modal.Footer>
      </Modal>
      <Modal show={show1}
      // onHide={()=>handleClose1}
      >
        <Modal.Header closeButton>
          <Modal.Title>Add Bug Details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
            <Form onSubmit={(e) => handleSubmit1(e, id)}>
            <div className="container">
              <div>
                <label>Bug Name</label>
                <input type="text" className="form-control" placeholder="Enter BugName"
                  value={editBugName} onChange={(e) => setEditBugName(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Description</label>
                <input type="text" className="form-control" placeholder="Enter description"
                  value={editBugDescription} onChange={(e) => setEditBugDescription(e.target.value)}
                />
              </div>
              <div>
                <label>Bug Status</label>
                <input type="text" className="form-control" placeholder="Enter Status"
                  value={editBugStatus} onChange={(e) => setEditBugStatus(e.target.value)}
                />
              </div>
              <div>
                <label>Project</label>
                <input type="text" className="form-control" placeholder="Enter Project"
                  value={editProject} onChange={(e) => setEditProject(e.target.value)}
                />
              </div>
              <div>
                <label>Raised By</label>
                <input type="text" className="form-control" placeholder="Raised By"
                  value={editRaisedBy} onChange={(e) => setEditRaisedBy(e.target.value)}
                />
              </div>
            </div>
            <div>
                <FormGroup>
                <Button variant="secondary"
                // onClick={()=>handleClose1}
                >
            Close
          </Button>
                </FormGroup>
                <FormGroup><Button variant="primary" type='submit' >
            Save Changes
          </Button></FormGroup>
            </div>
            </Form>
          </Modal.Body>
        <Modal.Footer>
        </Modal.Footer>
      </Modal>
      <Modal
      show={show1}
      // onHide={()=>handleClose1}
      >
  <Modal.Header closeButton>
    <Modal.Title>Edit Bug Details</Modal.Title>
  </Modal.Header>
  <Modal.Body>
    <Form onSubmit={(e) => handleSubmit1(e, id)}>
      <div className="container">
        <div>
          <label>Bug Name</label>
          <input
            type="text"
            className="form-control"
            placeholder="Enter Bug Name"
            value={editBugName}
            onChange={(e) => setEditBugName(e.target.value)}
          />
        </div>
        <div>
          <label>Bug Description</label>
          <input
            type="text"
            className="form-control"
            placeholder="Enter description"
            value={editBugDescription}
            onChange={(e) => setEditBugDescription(e.target.value)}
          />
        </div>
        <div>
          <label>Bug Status</label>
          <select
            className="form-control"
            value={editBugStatus}
            onChange={(e) => setEditBugStatus(e.target.value)}
          >
            {bugStatuses.map((status:any) => (
              <option key={status.statusID} value={status.statusID}>
                {status.statusName}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label>Project</label>
          <div>
                <label>Project</label>
                <input type="text" className="form-control" placeholder="Enter Project"
                  value={editProject}
                  onChange={(e) => setEditProject(e.target.value)}/>
        </div>
        <div>
          <label>Raised By</label>
          <input
            type="text"
            className="form-control"
            placeholder="Raised By"
            value={editRaisedBy}
            onChange={(e) => setEditRaisedBy(e.target.value)}
          />
        </div>
      </div>
      </div>
      <div>
        <FormGroup>
          <Button variant="secondary" onClick={handleClose1}>
            Close
          </Button>
        </FormGroup>
        <FormGroup>
          <Button variant="primary" type="submit">
            Save Changes
          </Button>
        </FormGroup>
      </div>
    </Form>
  </Modal.Body>
  <Modal.Footer>
  </Modal.Footer>
</Modal>
      </div>
    </div>
  );
};

export default ManageBugs;