import { validateHeaderName } from 'http';
import React, { useState } from 'react';
import { useSelector } from 'react-redux';
import { Link, Navigate } from 'react-router-dom';
import { toast,ToastContainer } from 'react-toastify';
import { Toast } from 'react-toastify/dist/components';
import { text } from 'stream/consumers';
import Input from '../../../components/app/input/input';
import { loginApi } from '../../../redux/actions/authentication';
import { AppState, useAppThunkDispatch } from '../../../redux/store';
import './Login.css';

const Login = () => {
    const [userName, setUserName]= useState('');
    const [password, setPassword]= useState('');
    const [newError, setError] = useState<{ userName?: string; password?: string }>({});
    const dispatch = useAppThunkDispatch();

    const User = useSelector((state: AppState) => state.login);
  // eslint-disable-next-line no-console
  const validate = () => {
    const newError: {
        userName?: string;
        password?: string;
    } = {};

    if (!userName) {
        newError.userName = 'Username is required';
    } else if (!userName.match('^(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]+$')) {
        newError.userName = 'Username is not valid';
    }
    if (!password) {
        newError.password = 'Password is required';
     } else if (!password.match('^(?=.*[a-z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{5,}$')) {
          newError.password = 'Password Invalid';
        }
    setError(newError);
    return Object.keys(newError).length === 0;
      };


  const Handleclick =(e:any)=>{

     e.preventDefault();
    if (validate()){
      dispatch(loginApi({
        userName,password
      }));
    }
    else{
      toast.error('Invalid Credentials');
    }

  };


    return(
      <>
      <ToastContainer/>
      <div className='maincontainer'>
        <div className='container-fluid'>
            <div className='row no-gutter'>
                <div className='col-md-6 d-none d-md-flex bg-image'></div>
                <div className='col-md-6 bg-light'>
                    <div className='login d-flex align-items-center py-5'>
                        <div className='container LoginComponents'>
                            <div className='row LoginCard'>
                                <div className='col-lg-10 col-xl-7 mx-auto'>
                                    <h3 className='display-4'>LOGIN</h3>
                                    <form>
                                    <div className="form-group mt-3">
                                      <label>UserName</label>
                                      <input
                                        type="text"
                                        className="form-control mt-1 userName"
                                        placeholder="Enter username"
                                        onChange={(e) => {
                                          setUserName(e.target.value);
                                        }}
                                      />
                                      {newError.userName && <span className="error">{newError.userName}</span>}
                                    </div>
                                    <div className="form-group mt-3">
                                      <label>Password</label>
                                      <input
                                        type="password"
                                        className="form-control mt-1"
                                        placeholder="Enter password"
                                        onChange={(e) => {
                                          setPassword(e.target.value);
                                        }}
                                      />
                                      {newError.password && <span className="error">{newError.password}</span>}

                                    </div>
                                        <div className='d-grid gap-2 mt-2'>
                                        <button type='submit' onClick={Handleclick}
                                         className='btn btn-primary btn-block text-uppercase
                                         mb-2 rounded-pill shadow-sm'>
                                          Sign in</button>
                                        </div>

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
      </>
    );
};
export default Login;


