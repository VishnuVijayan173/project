export interface IUser{
    userId: string,
    userName: string
}

export interface IUserLogin{
    password: string,
    userName: string
}