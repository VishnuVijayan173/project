import React from 'react';
import { Button, Container, Nav, Navbar, NavDropdown,Form } from 'react-bootstrap';
import {  Link, Navigate } from 'react-router-dom';
import Login from '../../pages/User/Login/Login';
import './header.css';

function Logout(){

    window.location.href='http://localhost:3000/';
    sessionStorage.clear();
}

const Header = () => (

    <>
        <Navbar bg="dark" variant="dark" expand="lg" id="NavBar">
        <Navbar.Brand className="app-logo" href="/">
            <img
              src="https://cdn3.iconfinder.com/data/icons/spring-2-1/30/Ladybug-256.png"
              width="40"
              height="50"
              className="d-inline-block align-center"
              alt="React Bootstrap logo"
            />{' '}
            BUG TRACKER
        </Navbar.Brand>
        <div className='LogOutButton'>
        <Button variant="primary" onClick={Logout}> Logout</Button>{' '}
        </div>
    </Navbar>
    </>
);
export default Header;
