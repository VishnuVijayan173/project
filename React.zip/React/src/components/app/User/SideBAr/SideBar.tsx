import React from 'react';
import {
  CDBSidebar,
  CDBSidebarContent,
  CDBSidebarHeader,
  CDBSidebarMenu,
  CDBSidebarMenuItem,
} from 'cdbreact';
import { Navigate, NavLink} from 'react-router-dom';
import {Navbar, Button, Nav, Container,Form} from 'react-bootstrap';
// import logo from '../static/logo.png';
import './SideBar.css';
import {useNavigate} from 'react-router-dom';
import UserList from '../../../../pages/Admin/UserList/UserList';



const SideBar = (props:any) => (
    <div>
        <div className='sidebar'>
            <CDBSidebar textColor='white'
                backgroundColor=""
                className={''}
                breakpoint={0}
                toggled={false}
                minWidth={''}
                maxWidth={''}>
                <CDBSidebarHeader prefix={<i className="fa fa-bars"  />}>
                    Logged in :
                </CDBSidebarHeader>
                <CDBSidebarContent>
                    <CDBSidebarMenu className='MenuItems'>
                        <NavLink exact to='/dashboard' activateClassName="activeClicked" {...props}>
                            <CDBSidebarMenuItem icon="home">Home</CDBSidebarMenuItem>
                        </NavLink>
                        <NavLink exact to="/dashboard/manage" activeClassName="activeClicked"{...props }>
                            <CDBSidebarMenuItem icon="user">Manage Bugs</CDBSidebarMenuItem>
                        </NavLink>
                        <NavLink exact to="/dashboard/bugList" activeClassName="activeClicked"{...props }>
                            <CDBSidebarMenuItem icon="user"> Bugs</CDBSidebarMenuItem>
                        </NavLink>
                    </CDBSidebarMenu>
                </CDBSidebarContent>
            </CDBSidebar>
        </div>
    </div>
);

export default SideBar;