import React from 'react';

const Input = (props: {
    value: string;
    onChange:(data: string)=>void;
    type:string;
}) => {
    return (
        <>
        <input
                type={props.type}
                className="form-control mt-1"
                value={props.value}
                onChange={(e) => {props.onChange(e.target.value);
                }} />
        </>
    );
};
export default Input;
