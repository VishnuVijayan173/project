import { AnyAction, Dispatch } from 'redux';
import { LOGIN } from './types';
import { handleError } from '../../utils/handle-error';
import axios from 'axios';
import { toast } from 'react-toastify';
import { IUserLogin } from '../../interfaces/user/user';

export const loginApi = (data:IUserLogin) => async (dispatch: Dispatch<AnyAction>) => {
    try {
        // eslint-disable-next-line no-console
        console.log(data);
        const response = await axios.post('https://localhost:44368/User/login', {
        userName : data.userName,
        password : data.password,
    });
    if (response.status === 200) {
        sessionStorage.setItem('token',response.data.token);
        sessionStorage.setItem('Role',response.data.roleId);
        toast.success('Logged in Successfully');

        if(response.data.roleId == 'd9231152-abac-43bc-2687-08db0f52477d'){
            alert('ADMIN LOGIN SUCCESFULLY');
            window.location.href ='http://localhost:3000/admin';
        }else if(response.data.roleId == 'fae9bc25-a294-49d6-2688-08db0f52477d'){
            alert('USER LOGIN SUCCESFULLY');
            window.location.href ='http://localhost:3000/Dashboard';
        }
    } else {
        alert('Incorrect username or password');
    }
        dispatch({
            type: LOGIN,
            payload: response.data,
        });


        return response.data.result;
    }
     catch (err: any) {
        handleError(err);
    }
};